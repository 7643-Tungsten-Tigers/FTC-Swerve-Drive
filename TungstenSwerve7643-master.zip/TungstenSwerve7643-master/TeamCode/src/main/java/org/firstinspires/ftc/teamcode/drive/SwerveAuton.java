package org.firstinspires.ftc.teamcode.drive;

import static org.firstinspires.ftc.teamcode.drive.DriveConstants.DIAGONAL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.GEAR_RATIO;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ACCEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ANG_ACCEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_ANG_VEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MAX_VEL;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.MOTOR_VELO_PID;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.RUN_USING_ENCODER;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.TICKS_PER_REV;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.TRACK_WIDTH;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.WHEEL_BASE;
import static org.firstinspires.ftc.teamcode.drive.DriveConstants.WHEEL_RADIUS;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.control.PIDCoefficients;
import com.acmerobotics.roadrunner.drive.DriveSignal;
import com.acmerobotics.roadrunner.drive.SwerveDrive;
import com.acmerobotics.roadrunner.followers.HolonomicPIDVAFollower;
import com.acmerobotics.roadrunner.followers.TrajectoryFollower;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryBuilder;
import com.acmerobotics.roadrunner.trajectory.constraints.AngularVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.MinVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.ProfileAccelerationConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.SwerveVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryAccelerationConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryVelocityConstraint;
import com.acmerobotics.roadrunner.util.Angle;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.drive.opmode.trajectorysequence.TrajectorySequence;
import org.firstinspires.ftc.teamcode.drive.opmode.trajectorysequence.TrajectorySequenceBuilder;
import org.firstinspires.ftc.teamcode.drive.opmode.trajectorysequence.TrajectorySequenceRunner;
import org.firstinspires.ftc.teamcode.drive.subsystems.SwerveModule;
import org.firstinspires.ftc.teamcode.drive.subsystems.SwerveModuleAuton;
import org.firstinspires.ftc.teamcode.subsystems.Constants;
import org.firstinspires.ftc.teamcode.util.LynxModuleUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Config
public class SwerveAuton extends SwerveDrive {

    private TrajectoryFollower follower=null;
    public SwerveModuleAuton[]  swervmods= new SwerveModuleAuton[4];
    private DcMotorEx leftFront, leftRear, rightRear, rightFront;
    private CRServo lfServo, lrServo, rrServo, rfServo;
    private AnalogInput lfAng, lrAng, rrAng, rfAng;
    private IMU imu;
    private VoltageSensor batteryVoltageSensor;
    private List<DcMotorEx> motors;
    private Telemetry telem;



    private double A,B,C,D, TWOPI=2*Math.PI;
    private double wlf, wlr, wrr, wrf,mx;

    private double lpv, lpv1, lpv2, lpv3;


    public static PIDCoefficients TRANSLATIONAL_PID = new PIDCoefficients(5.5, 0, 0);
    //public static PIDCoefficients HEADING_PID = new PIDCoefficients(6, 1, 0.1);
    public static PIDCoefficients HEADING_PID = new PIDCoefficients(4, 2.0, 0.2);

    private TrajectorySequenceRunner trajectorySequenceRunner;

    private static  TrajectoryVelocityConstraint VEL_CONSTRAINT = getVelocityConstraint(MAX_VEL, MAX_ANG_VEL, TRACK_WIDTH, WHEEL_BASE);
    private static  TrajectoryAccelerationConstraint ACCEL_CONSTRAINT = getAccelerationConstraint(MAX_ACCEL);


    private List<Integer> lastEncPositions = new ArrayList<>();
    private List<Integer> lastEncVels = new ArrayList<>();
    private List<Double> lastModlueOrientation = new ArrayList<>();



    public SwerveAuton(HardwareMap hardwareMap, Telemetry telem) {
        super(DriveConstants.kV, DriveConstants.kA, DriveConstants.kStatic, TRACK_WIDTH, WHEEL_BASE);
        this.telem=telem;

        follower = new HolonomicPIDVAFollower(TRANSLATIONAL_PID, TRANSLATIONAL_PID, HEADING_PID,
                new Pose2d(0.5, 0.5, Math.toRadians(5.0)), 0.5);




        LynxModuleUtil.ensureMinimumFirmwareVersion(hardwareMap);

        batteryVoltageSensor = hardwareMap.voltageSensor.iterator().next();

        for (LynxModule module : hardwareMap.getAll(LynxModule.class)) {
            module.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }

        // TODO: adjust the names of the following hardware devices to match your configuration
        imu = hardwareMap.get(IMU.class, "imu");
        IMU.Parameters parameters = new IMU.Parameters(new RevHubOrientationOnRobot(
                DriveConstants.LOGO_FACING_DIR, DriveConstants.USB_FACING_DIR));
        imu.initialize(parameters);


        leftFront = hardwareMap.get(DcMotorEx.class, "lf");
        leftRear = hardwareMap.get(DcMotorEx.class, "lr");
        rightRear = hardwareMap.get(DcMotorEx.class, "rr");
        rightFront = hardwareMap.get(DcMotorEx.class, "rf");

        lfServo=hardwareMap.get(CRServo.class, "servo1");
        lrServo=hardwareMap.get(CRServo.class, "servo2");
        rrServo=hardwareMap.get(CRServo.class, "servo3");
        rfServo=hardwareMap.get(CRServo.class, "servo4");

        lfAng=hardwareMap.get(AnalogInput.class, "enc1");
        lrAng=hardwareMap.get(AnalogInput.class, "enc2");
        rrAng=hardwareMap.get(AnalogInput.class, "enc3");
        rfAng=hardwareMap.get(AnalogInput.class, "enc4");

        swervmods[0]=new SwerveModuleAuton(hardwareMap,lfAng, leftFront, lfServo, telem,3.2775, Constants.Chassis.leftFrontOffset, 0);
        swervmods[1]=new SwerveModuleAuton(hardwareMap,lrAng, leftRear, lrServo, telem, 3.261,Constants.Chassis.leftRearOffset, 1);
        swervmods[2]=new SwerveModuleAuton(hardwareMap,rrAng, rightRear, rrServo, telem, 3.282,Constants.Chassis.rightRearOffset,2);
        swervmods[3]=new SwerveModuleAuton(hardwareMap,rfAng, rightFront, rfServo, telem, 3.282,Constants.Chassis.rightFrontOffset,3);

        motors = Arrays.asList(leftFront, leftRear, rightRear, rightFront);

        for (DcMotorEx motor : motors) {
            MotorConfigurationType motorConfigurationType = motor.getMotorType().clone();
            motorConfigurationType.setAchieveableMaxRPMFraction(1.0);
            motor.setMotorType(motorConfigurationType);
        }

        if (RUN_USING_ENCODER) {
            setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        }

        setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        if (RUN_USING_ENCODER && MOTOR_VELO_PID != null) {
            setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER, MOTOR_VELO_PID);
        }

        // TODO: reverse any motors using DcMotor.setDirection()

        List<Integer> lastTrackingEncPositions = new ArrayList<>();
        List<Integer> lastTrackingEncVels = new ArrayList<>();

        // TODO: if desired, use setLocalizer() to change the localization method
        // setLocalizer(new StandardTrackingWheelLocalizer(hardwareMap, lastTrackingEncPositions, lastTrackingEncVels));

        trajectorySequenceRunner = new TrajectorySequenceRunner(
                follower, HEADING_PID, batteryVoltageSensor,
                lastEncPositions, lastEncVels, lastTrackingEncPositions, lastTrackingEncVels
        );

    }

    public TrajectoryBuilder trajectoryBuilder(Pose2d startPose) {
        return new TrajectoryBuilder(startPose, VEL_CONSTRAINT, ACCEL_CONSTRAINT);
    }

    public TrajectoryBuilder trajectoryBuilder(Pose2d startPose, boolean reversed) {
        return new TrajectoryBuilder(startPose, reversed, VEL_CONSTRAINT, ACCEL_CONSTRAINT);
    }

    public TrajectoryBuilder trajectoryBuilder(Pose2d startPose, double startHeading) {
        return new TrajectoryBuilder(startPose, startHeading, VEL_CONSTRAINT, ACCEL_CONSTRAINT);
    }

    public TrajectorySequenceBuilder trajectorySequenceBuilder(Pose2d startPose) {
        return new TrajectorySequenceBuilder(
                startPose,
                VEL_CONSTRAINT, ACCEL_CONSTRAINT,
                MAX_ANG_VEL, MAX_ANG_ACCEL
        );
    }

    public void turnAsync(double angle) {
        trajectorySequenceRunner.followTrajectorySequenceAsync(
                trajectorySequenceBuilder(getPoseEstimate())
                        .turn(angle)
                        .build()
        );
    }

    public void turn(double angle) {
        turnAsync(angle);
        waitForIdle();
    }

    public void turnto(double angle) {

//fix raw heading quadrant issues

        angle -= getRawExternalHeading();
        if(angle>180)  {
            angle=angle-360;
        }else if(angle<-180){
            angle=angle+360;
        }

        turn(angle);
    }

    public void followTrajectoryAsync(Trajectory trajectory) {
        trajectorySequenceRunner.followTrajectorySequenceAsync(
                trajectorySequenceBuilder(trajectory.start())
                        .addTrajectory(trajectory)
                        .build()
        );
    }

    public void followTrajectory(Trajectory trajectory) {
        followTrajectoryAsync(trajectory);
        waitForIdle();
    }

    public void followTrajectorySequenceAsync(TrajectorySequence trajectorySequence) {
        trajectorySequenceRunner.followTrajectorySequenceAsync(trajectorySequence);
    }

    public void followTrajectorySequence(TrajectorySequence trajectorySequence) {
        followTrajectorySequenceAsync(trajectorySequence);
        waitForIdle();
    }

    public Pose2d getLastError() {
        return trajectorySequenceRunner.getLastPoseError();
    }

    public void update() {
        updatePoseEstimate();
        DriveSignal signal = trajectorySequenceRunner.update(getPoseEstimate(), getPoseVelocity());
        if (signal != null) setDriveSignal(signal);
    }

    public void waitForIdle() {
        while (!Thread.currentThread().isInterrupted() && isBusy())
            update();
    }

    public boolean isBusy() {
        return trajectorySequenceRunner.isBusy();
    }

    public void setMode(DcMotor.RunMode runMode) {
        for (DcMotorEx motor : motors) {
            motor.setMode(runMode);
        }
    }

    public void setZeroPowerBehavior(DcMotor.ZeroPowerBehavior zeroPowerBehavior) {
        for (DcMotorEx motor : motors) {
            motor.setZeroPowerBehavior(zeroPowerBehavior);
        }
    }

    public void setPIDFCoefficients(DcMotor.RunMode runMode, PIDFCoefficients coefficients) {
        PIDFCoefficients compensatedCoefficients = new PIDFCoefficients(
                coefficients.p, coefficients.i, coefficients.d,
                coefficients.f * 12 / batteryVoltageSensor.getVoltage()
        );

        for (DcMotorEx motor : motors) {
            motor.setPIDFCoefficients(runMode, compensatedCoefficients);
        }
    }


    public static TrajectoryVelocityConstraint getVelocityConstraint(double maxVel, double maxAngularVel, double trackWidth, double Wheelbase) {
        return new MinVelocityConstraint(Arrays.asList(
                new AngularVelocityConstraint(maxAngularVel),
                new SwerveVelocityConstraint(maxVel, trackWidth, Wheelbase)
        ));
    }

    public static TrajectoryAccelerationConstraint getAccelerationConstraint(double maxAccel) {
        return new ProfileAccelerationConstraint(maxAccel);
    }

    public double getHeadingDegrees(){
        return getRawExternalHeading()*180/Math.PI;
    }

    @Override
    protected double getRawExternalHeading() {
        return imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);
    }

    @NonNull
    @Override
    public List<Double> getModuleOrientations() {
        lastModlueOrientation.clear();

        List<Double> moduleOrientations = new ArrayList<>();
        for (SwerveModuleAuton mod : swervmods) {
            lastModlueOrientation.add(mod.getWheelAngle());
            moduleOrientations.add(mod.getWheelAngle());
        }
        return moduleOrientations;
    }

    @NonNull
    @Override
    public List<Double> getWheelPositions() {
        lastEncPositions.clear();

        List<Double> wheelPositions = new ArrayList<>();
        for (DcMotorEx motor : motors) {
            int position = motor.getCurrentPosition();
            lastEncPositions.add(position);
            wheelPositions.add(encoderTicksToInches(position));
        }
        return wheelPositions;
    }

    @NonNull
    @Override
    public List<Double> getWheelVelocities() {
        lastEncVels.clear();

        List<Double> wheelVelocities = new ArrayList<>();
        for (DcMotorEx motor : motors) {
            int vel = (int) motor.getVelocity();
            lastEncVels.add(vel);
            wheelVelocities.add(encoderTicksToInches(vel));
        }
        return wheelVelocities;
    }

    @Override
    public void setModuleOrientations(double v, double v1, double v2, double v3) {
      //  swervmods[0].setWheelAngle(lpv,v);
      //   swervmods[1].setWheelAngle(lpv1,v1);
      //  swervmods[2].setWheelAngle(lpv2,v2);
      //  swervmods[3].setWheelAngle(lpv3,v3);

        swervmods[0].setModuleSate(lpv,v);
        swervmods[1].setModuleSate(lpv,v1);
        swervmods[2].setModuleSate(lpv,v2);
        swervmods[3].setModuleSate(lpv,v3);


    }

    @Override
    public void setMotorPowers(double v, double v1, double v2, double v3) {
     //  swervmods[0].setWheelPower(v);
    //  swervmods[1].setWheelPower(v1);
    //   swervmods[2].setWheelPower(v2);
    //   swervmods[3].setWheelPower(v3);

        lpv=v;
        lpv1=v1;
        lpv2=v2;
        lpv3=v3;

    }

    public double encoderTicksToInches(double ticks){
        return ticks*2*Math.PI*(WHEEL_RADIUS)/(TICKS_PER_REV * GEAR_RATIO);
    }

    public double encoderTicksToIPS(double vel){
        return vel*(WHEEL_RADIUS)/GEAR_RATIO;
    }

    public void OL_setState(double fwd, double str, double rot){
        A=str-rot*WHEEL_BASE/DIAGONAL;
        B=str+rot*WHEEL_BASE/DIAGONAL;
        C=fwd-rot*TRACK_WIDTH/DIAGONAL;
        D=fwd+rot*TRACK_WIDTH/DIAGONAL;

        wlf=Math.sqrt(B*B+D*D);
        wlr=Math.sqrt(A*A+D*D);
        wrr=Math.sqrt(A*A+C*C);
        wrf=Math.sqrt(B*B+C*C);

        List<Double> speeds= Arrays.asList(Math.abs(wlf), Math.abs(wlr), Math.abs(wrr), Math.abs(wrf));
        mx=Collections.max(speeds);

        if(mx>1){
            wlf/=mx;
            wlr/=mx;
            wrr/=mx;
            wrf/=mx;
        }


        swervmods[0].setModuleSate(wlf, TWOPI -Math.atan2(B,D));


        swervmods[1].setModuleSate(wlr, TWOPI -Math.atan2(A,D));


        swervmods[2].setModuleSate(wrr, TWOPI -Math.atan2(A,C));

        swervmods[3].setModuleSate(wrf, TWOPI -Math.atan2(B,C));

    }

    public void OL_setWheelAngle(double ang){

        swervmods[0].setWheelPower(0);
        swervmods[0].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[1].setWheelPower(0);
        swervmods[1].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[2].setWheelPower(0);
        swervmods[2].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[3].setWheelPower(0);
        swervmods[3].setWheelAngleOnly(Math.toRadians(ang));
    }

    public void OL_setSingleState(double fwd, double str, double rot){
        A=str-rot*WHEEL_BASE/DIAGONAL;
        B=str+rot*WHEEL_BASE/DIAGONAL;
        C=fwd-rot*TRACK_WIDTH/DIAGONAL;
        D=fwd+rot*TRACK_WIDTH/DIAGONAL;

        wlf=Math.sqrt(B*B+D*D);
        wlr=Math.sqrt(A*A+D*D);
        wrr=Math.sqrt(A*A+C*C);
        wrf=Math.sqrt(B*B+C*C);

        List<Double> speeds= Arrays.asList(Math.abs(wlf), Math.abs(wlr), Math.abs(wrr), Math.abs(wrf));
        mx=Collections.max(speeds);

        if(mx>1){
            wlf/=mx;
            wlr/=mx;
            wrr/=mx;
            wrf/=mx;
        }



        swervmods[0].setModuleSate(wlf, TWOPI -Math.atan2(B,D));


      //  swervmods[1].setModuleSate(wlr, TWOPI - Math.atan2(A,D));


      //  swervmods[2].setModuleSate(wrr, TWOPI - Math.atan2(A,C));

      //  swervmods[3].setModuleSate(wrf, TWOPI - Math.atan2(B,C));

    }

    public void OL_setSingleWheelAngle(double ang){

        swervmods[0].setWheelPower(0);
        swervmods[0].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[1].setWheelPower(0);
        swervmods[1].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[2].setWheelPower(0);
        swervmods[2].setWheelAngleOnly(Math.toRadians(ang));

        swervmods[3].setWheelPower(0);
        swervmods[3].setWheelAngleOnly(Math.toRadians(ang));
    }

    public void set_ForSpin(){

        A=-WHEEL_BASE/DIAGONAL;
        B=WHEEL_BASE/DIAGONAL;
        C=-TRACK_WIDTH/DIAGONAL;
        D=TRACK_WIDTH/DIAGONAL;

        swervmods[0].setWheelPower(0);
        swervmods[0].setWheelAngleOnly(TWOPI -Math.atan2(B,D));
        swervmods[1].setWheelPower(0);
        swervmods[1].setWheelAngleOnly(TWOPI -Math.atan2(A,D));
        swervmods[2].setWheelPower(0);
        swervmods[2].setWheelAngleOnly(TWOPI -Math.atan2(A,C));
        swervmods[3].setWheelPower(0);
        swervmods[3].setWheelAngleOnly(TWOPI -Math.atan2(B,C));

    }

    public void setVelConstraint(TrajectoryVelocityConstraint cons){
        VEL_CONSTRAINT=cons;
        return;
    }

    public void setAclConstraint(TrajectoryAccelerationConstraint acl){
        ACCEL_CONSTRAINT=acl;
        return;
    }

    public void imureset(){
        imu.resetYaw();
    }


    public double readGyro(){
        return imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);
    }


    public void imurecover(){



        imu.resetYaw();

        IMU.Parameters parameters = new IMU.Parameters(new RevHubOrientationOnRobot(
                DriveConstants.LOGO_FACING_DIR, DriveConstants.USB_FACING_DIR));
        imu.initialize(parameters);

    }

    public void breakFollowing() {
        trajectorySequenceRunner.breakFollowing();
    }



}
