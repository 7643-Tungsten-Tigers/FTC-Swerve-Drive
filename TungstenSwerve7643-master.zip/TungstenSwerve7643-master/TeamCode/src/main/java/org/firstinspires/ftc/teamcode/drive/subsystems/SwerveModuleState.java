package org.firstinspires.ftc.teamcode.drive.subsystems;

public class SwerveModuleState {

    public double modSpeed;
    public double modAng;
    public SwerveModule module;


    public SwerveModuleState(SwerveModule module, double modpos, double modang){
        this.modSpeed=modpos;
        this.modAng=modang;
        this.module=module;

    }


}
