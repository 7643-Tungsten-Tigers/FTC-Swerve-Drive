package org.firstinspires.ftc.teamcode.subsystems;

public class Constants {



    public static class Chassis{
  
        public static double leftFrontOffset=0.643;
        public static double leftRearOffset=1.931;
        public static double rightRearOffset=0.407;
        public static double rightFrontOffset=0.778;

    }

    





}