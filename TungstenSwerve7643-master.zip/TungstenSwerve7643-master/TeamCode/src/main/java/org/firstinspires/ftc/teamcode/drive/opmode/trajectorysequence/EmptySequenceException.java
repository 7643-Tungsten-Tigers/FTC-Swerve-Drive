package org.firstinspires.ftc.teamcode.drive.opmode.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
